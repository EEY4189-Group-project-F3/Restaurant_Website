document.getElementById('approveButton').addEventListener('click', function() {
  const email = document.getElementById('emailInput').value;
  
  if (email) {
    // Using mailto: to open the default email client
    window.location.href = `mailto:${email}?subject=Approval Request&body=Your request has been approved.`;
  } else {
    alert('Please enter a valid email address');
  }
});
